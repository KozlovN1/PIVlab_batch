% by NK
% Write below the adjustments appropriate to your ROI transformation with
% time.

% e.g.
% roiwidth = roiwidth_0 + roi_C1*power(counter-1,roi_pow); %% This law is obtained from experiment by measuring front coordinate or window width
% s{5,2}(3)=round(roiwidth); 
